# Project Notes

The frontend in `public/index.html` is the supplied application, preserved as the main working UI.
The Express server is a lightweight wrapper so the application can be run as a normal Node.js project.

No external database or SMS credentials are embedded.


PEOPLE PORTAL RULE: Donors are registered only through people-portal. The main portal reads the central /api/donors list and does not add local donor records to that list. Only completed donor profiles (DOB, age >=18, blood group, city) appear as active donors.
