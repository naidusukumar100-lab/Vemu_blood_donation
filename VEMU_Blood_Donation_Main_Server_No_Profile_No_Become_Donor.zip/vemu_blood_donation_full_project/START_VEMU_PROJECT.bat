@echo off
title VEMU Blood Donation + People Portal
cd /d "%~dp0"
if not exist node_modules (echo Installing main server packages... & call npm install)
if not exist people-portal\node_modules (echo Installing People Portal packages... & cd people-portal & call npm install & cd ..)
echo Starting Main Blood Donation Server on port 3000...
start "VEMU Main Server" cmd /k "cd /d %~dp0 && npm start"
timeout /t 2 /nobreak >nul
echo Starting People Portal on port 3001...
start "VEMU People Portal" cmd /k "cd /d %~dp0people-portal && npm start"
timeout /t 2 /nobreak >nul
start "" http://localhost:3000
start "" http://localhost:3001
