# VEMU Blood Donation Platform — Final Year Project

## Features
- Responsive Home dashboard
- Donor registration with DOB-based 18+ verification
- Permanent browser storage for donors, requests and drives
- Find donors by blood group, location and availability
- Donor history with restore/delete controls
- My Donor Profile with availability toggle
- Emergency blood request with 24-hour expiry countdown
- Mobile browser geolocation for emergency requests
- Same-blood-group donor matching and local browser alerts
- Request location map link
- Donation drives and RSVP
- Hospitals / blood-bank information
- Project Dashboard with blood-group availability and emergency summary
- Export project data as JSON
- Clear local project data for demonstration/reset
- Node.js + Express main server
- Separate People Portal with account authentication and central profile/request APIs

## Requirements
- Node.js 18 or newer
- Internet connection for CDN assets (Tailwind CSS and Font Awesome)

## Run on Windows
1. Extract this ZIP.
2. Open the extracted `vemu_blood_donation_full_project` folder.
3. Click the File Explorer address bar, type `cmd`, and press Enter.
4. Run:

```cmd
npm install
npm start
```

5. Open `http://localhost:3000` in Chrome or Edge.

Keep the Command Prompt window open while using the site.

## Important
This project is a college/demo application. Data is stored in the current browser using localStorage. Cross-phone SMS, WhatsApp, push notifications, authenticated admin access and a central database require a production backend/service.

## NEW: Separate People Login Portal
The project now includes `people-portal/`, a separate login/account web project connected to this main server.

### Run both projects on Windows
Terminal 1:
```cmd
cd vemu_blood_donation_full_project
npm install
npm start
```
Open: `http://localhost:3000`

Terminal 2:
```cmd
cd vemu_blood_donation_full_project\people-portal
npm install
npm start
```
Open: `http://localhost:3001`

The People Portal provides separate account registration/login, central donor profiles and 24-hour emergency requests. The main server stores account data in `data/users.json` and emergency requests in `data/emergency-requests.json` for this college/demo project.


## Architecture
```text
VEMU Blood Donation Platform (Main Server :3000)
              ^
              | REST API / authenticated accounts
              v
VEMU People Portal (Separate Project :3001)
              |
              +-- Login / Register
              +-- Donor Profile
              +-- Emergency Request
```

`data/users.json` stores account records for this college/demo project. Passwords are stored as salted scrypt hashes. For production, move authentication and personal data to a managed database and use HTTPS.

## One-click Windows start
Double-click `START_VEMU_PROJECT.bat`. It installs missing Node packages, starts both servers, and opens both URLs.
