# VEMU People Portal

Separate login/account project connected to the main VEMU Blood Donation server.

## Start the main server
```cmd
cd vemu_blood_donation_full_project
npm install
npm start
```
Main project: http://localhost:3000

## Start the People Portal
Open a second Command Prompt:
```cmd
cd vemu_blood_donation_full_project\people-portal
npm install
npm start
```
People Portal: http://localhost:3001

## What it adds
- Separate account registration and login
- Passwords stored as salted scrypt hashes on the main server, not plain text
- 7-day login session tokens
- Central donor profile linked to the account
- DOB-based 18+ donor verification
- Central emergency request storage with 24-hour expiry
- Mobile GPS capture for emergency requests
- Link back to the main VEMU Blood Donation Platform

For deployment, replace localhost URLs with your HTTPS domains and use a production database/session store.
